clear
clc

x = [5.78;4.75;6.68;5.06;5.35;6.45;4.16;6.12;5.87;7.49;4.28;5.38;6.70;7.06;5.08;4.00;5.40;7.33;5.59;6.40];
y = [0.31;0.16;0.42;0.21;0.26;0.40;0.04;0.36;0.33;0.50;0.07;0.26;0.42;;0.46;0.21;0.00;0.26;0.49;0.29;0.39];

#grafico de dispersao
plot(x, y, 'ob');
title('Grafico de dispersao e reta ajustada')
hold on
[b, r2, s2, AICc, Info]  = regressao_linear_en (length(x), 1, 2, 1, x', y')

xplot = linspace(min(x), max(x), 50);
yplot = b(1) + b(2)*xplot;
plot(xplot, yplot, '-r');
